# COMMENT METTRE MHSHOP DANS TON REPO MH EXISTANT

Tu as déjà un repo qui s'appelle "mh" sur GitHub. Parfait, on va juste remplacer son contenu par mhshop.

## METHODE 1 - La plus simple (sans code, sur le site GitHub)

### 1. Vide ton repo mh (si il a des vieux fichiers)

- Va sur github.com/TON_PSEUDO/mh
- Clique sur chaque fichier -> clique sur la corbeille (Delete) -> Commit
- Ou plus rapide: va dans Settings de ton repo -> tout en bas -> Delete this repository -> recrée-le vide avec le même nom "mh" (plus rapide si y'a beaucoup de fichiers)

### 2. Upload mhshop dedans

- Télécharge: mhshop-vercel-ready.tar.gz
- Décompresse avec 7-Zip -> tu as un dossier "mhshop" avec plein de fichiers
- Va sur ton repo https://github.com/TON_PSEUDO/mh
- Clique "Add file" -> "Upload files"
- Ouvre ton dossier mhshop sur ton PC -> Ctrl+A (tout sélectionner) -> glisse tout dans GitHub
- Attends que ça upload -> en bas clique "Commit changes"

C'est tout ! Ton repo mh contient maintenant mhshop.

### 3. Déploie sur Vercel

- Va sur vercel.com -> Login avec GitHub
- Si tu avais déjà importé mh avant:
  - Va dans ton projet Vercel -> Deployments -> il va se redéployer tout seul quand tu push sur GitHub
  - Sinon clique "Redeploy" manuellement

- Si tu avais jamais importé mh:
  - Add New Project -> Import mh -> Deploy

### 4. Mets les 3 clés (sinon 404)

Dans Vercel -> ton projet mh -> Settings -> Environment Variables:

DATABASE_URL = ta clé Neon (va sur neon.tech -> Create Project -> copie la connection string)
AUTH_SECRET = https://generate-secret.vercel.app/32
ENCRYPTION_KEY = https://generate-random.org/hex -> 64 caractères

Save -> Deployments -> Redeploy (sans cache)

Attends Ready -> Visit -> va sur /register pour créer ton compte

## METHODE 2 - Avec Git (si tu as VS Code)

Dans VS Code:

```bash
git clone https://github.com/TON_PSEUDO/mh.git
cd mh
# copie tous les fichiers de mhshop dedans (remplace tout)
git add .
git commit -m "mhshop v1"
git push
```

Vercel va redéployer tout seul.

---

## VERIFIE QUE CA A MARCHE

Va sur https://github.com/TON_PSEUDO/mh

Tu dois voir à la racine:
- app/
- lib/
- prisma/
- package.json
- vercel.json
- etc.

Si tu vois un dossier "mhshop" dedans (mh/mhshop/app), alors dans Vercel -> Settings -> General -> Root Directory -> mets "mhshop" -> Save -> Redeploy

Sinon laisse Root Directory vide.

Une fois Ready, ton site sera sur https://mh-xxx.vercel.app
