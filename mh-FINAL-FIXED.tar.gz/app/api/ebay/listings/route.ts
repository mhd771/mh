import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { fetchUserListings } from '@/services/ebay/client';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Non auth' }, { status: 401 });

  try {
    const data = await fetchUserListings(session.user.id);
    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
