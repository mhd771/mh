import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import bcrypt from 'bcryptjs';
import { z } from 'zod';

const schema = z.object({ name: z.string().min(1), email: z.string().email(), password: z.string().min(6) });

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: 'Données invalides' }, { status: 400 });

    const existing = await prisma.user.findUnique({ where: { email: parsed.data.email } });
    if (existing) return NextResponse.json({ error: 'Email déjà utilisé' }, { status: 400 });

    const hash = await bcrypt.hash(parsed.data.password, 10);
    const user = await prisma.user.create({ data: { name: parsed.data.name, email: parsed.data.email, passwordHash: hash } });

    return NextResponse.json({ id: user.id });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
