# Guide Connexion eBay - mhshop (100% conforme)

## 1. Créer ton app eBay Developer
1. Va sur https://developer.ebay.com
2. Connecte-toi avec ton compte eBay vendeur
3. My Account > Application Keys > Create Application
4. Remplis nom: mhshop

Tu obtiens:
- App ID (Client ID)
- Cert ID (Client Secret)
- RuName: dans onglet "Auth" > Add eBay Redirect URL > Ajoute: https://ton-domaine.vercel.app/api/ebay/callback
  eBay va générer un RuName genre: Ahmed_Maleh-AhmedMale-mhshop--abc

## 2. Scopes à cocher
Coche uniquement:
- sell.inventory
- sell.marketing
- sell.account

## 3. Configuration .env
EBAY_CLIENT_ID=ton_app_id
EBAY_CLIENT_SECRET=ton_cert_id
EBAY_RU_NAME=ton_runame_exact
EBAY_ENV=sandbox (pour tester avec faux produits)
ENCRYPTION_KEY=openssl rand -hex 32

## 4. Flux utilisateur
- User va sur /dashboard/ebay > Clique "Connecter eBay"
- Redirigé vers auth.sandbox.ebay.com > Login eBay > Autoriser
- Retour sur /api/ebay/callback?code=xxx
- Serveur échange code contre tokens, chiffre avec AES-256-GCM, sauvegarde
- Plus jamais de mot de passe demandé

## 5. Tester sans risquer ta boutique
En sandbox, eBay te donne des comptes test. Tu peux créer 100 annonces fake.

## 6. Passer en production
Quand prêt: dans developer.ebay.com > Production Keys > Apply for production
eBay vérifie ton app (2-3 jours). Ensuite change EBAY_ENV=production

## Sécurité
- Jamais de scraping
- Jamais de stockage mot de passe
- Tokens chiffrés, refresh automatique
- CRON_SECRET pour protéger /api/cron/price-check

## Erreurs fréquentes
- invalid_ru_name: RuName ne correspond pas exactement à celui dans dashboard eBay
- invalid_scope: scope non coché dans dashboard
- token expired: normal, le code gère le refresh auto
