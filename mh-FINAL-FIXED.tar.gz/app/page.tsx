import Link from 'next/link';
export const dynamic = 'force-dynamic';
export default function Home() {
  const hasDb = !!process.env.DATABASE_URL;
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex flex-col">
      <header className="p-6 flex justify-between items-center border-b border-white/10">
        <div className="flex items-center gap-2"><div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center font-bold">m</div><span className="font-bold text-xl">mhshop</span></div>
        <div className="flex gap-3"><Link href="/login" className="px-4 py-2 text-sm text-white/70 hover:text-white">Connexion</Link><Link href="/register" className="px-5 py-2 bg-white text-black rounded-full text-sm font-medium">Commencer</Link></div>
      </header>
      <main className="flex-1 flex flex-col items-center justify-center text-center px-6">
        {!hasDb && <div className="mb-6 px-4 py-2 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-200 text-sm">⚠️ Ajoute DATABASE_URL dans Vercel → Settings → Env Vars puis Redeploy</div>}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/20 text-xs text-violet-300 mb-6">100% API eBay Officielle • Aucun scraping</div>
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight max-w-4xl">Gère ton empire<br/><span className="bg-gradient-to-r from-violet-400 to-indigo-400 bg-clip-text text-transparent">eBay & e-commerce</span></h1>
        <p className="mt-6 text-white/60 max-w-xl">Calculateur de marge, générateur IA, surveillance prix et connexion eBay OAuth sécurisée. Le tout-en-un inspiré d'AutoDS, mais en propre et conforme.</p>
        <div className="mt-8 flex gap-3"><Link href="/register" className="px-8 py-3 bg-white text-black rounded-full font-medium">Créer mon compte →</Link><Link href="/login" className="px-8 py-3 bg-white/5 border border-white/10 rounded-full">Démo dashboard</Link></div>
        <div className="mt-6 text-xs text-white/30">Build OK: {new Date().toISOString()}</div>
      </main>
    </div>
  );
}
