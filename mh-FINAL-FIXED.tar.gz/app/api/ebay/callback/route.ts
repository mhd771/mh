import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getEbayUrls } from '@/lib/ebay-config';
import { encrypt } from '@/lib/crypto';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get('code');
  const state = req.nextUrl.searchParams.get('state');
  const error = req.nextUrl.searchParams.get('error');

  if (error) {
    return NextResponse.redirect(`/dashboard/ebay?error=${error}`);
  }

  if (!code || !state) {
    return NextResponse.json({ error: 'Code ou state manquant' }, { status: 400 });
  }

  // Vérif state - extrait userId
  const [userId] = state.split(':');
  if (!userId) {
    return NextResponse.json({ error: 'State invalide' }, { status: 400 });
  }

  try {
    const urls = getEbayUrls();
    
    // Échange code -> tokens (Appel officiel eBay)
    const tokenRes = await fetch(urls.oauth, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Basic ${Buffer.from(`${process.env.EBAY_CLIENT_ID}:${process.env.EBAY_CLIENT_SECRET}`).toString('base64')}`,
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: process.env.EBAY_RU_NAME!,
      }),
    });

    if (!tokenRes.ok) {
      const err = await tokenRes.text();
      console.error('eBay token error:', err);
      return NextResponse.redirect('/dashboard/ebay?error=token_exchange_failed');
    }

    const tokens = await tokenRes.json() as {
      access_token: string;
      refresh_token: string;
      expires_in: number;
    };

    // Chiffrement avant stockage
    const encryptedAccess = encrypt(tokens.access_token);
    const encryptedRefresh = encrypt(tokens.refresh_token);
    const expiry = new Date(Date.now() + tokens.expires_in * 1000);

    // Sauvegarde en DB
    await prisma.ebayAccount.upsert({
      where: { userId },
      update: {
        accessToken: encryptedAccess,
        refreshToken: encryptedRefresh,
        tokenExpiry: expiry,
      },
      create: {
        userId,
        accessToken: encryptedAccess,
        refreshToken: encryptedRefresh,
        tokenExpiry: expiry,
      }
    });

    return NextResponse.redirect('/dashboard/ebay?connected=true');

  } catch (e) {
    console.error(e);
    return NextResponse.redirect('/dashboard/ebay?error=server_error');
  }
}
