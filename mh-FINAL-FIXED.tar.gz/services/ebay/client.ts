import { PrismaClient } from '@prisma/client';
import { getEbayUrls, getEbayEnv } from '@/lib/ebay-config';
import { encrypt, decrypt } from '@/lib/crypto';

const prisma = new PrismaClient();

interface EbayTokens {
  access_token: string;
  refresh_token?: string;
  expires_in: number;
}

export async function getValidAccessToken(userId: string): Promise<string> {
  const account = await prisma.ebayAccount.findUnique({ where: { userId } });
  if (!account) throw new Error('Compte eBay non connecté');

  // Si token encore valide 5 min, on le réutilise
  const now = new Date();
  const buffer = new Date(now.getTime() + 5 * 60 * 1000);
  
  if (account.tokenExpiry > buffer) {
    return decrypt(account.accessToken);
  }

  // Sinon refresh
  console.log('Refreshing eBay token for user', userId);
  const refreshed = await refreshEbayToken(decrypt(account.refreshToken));

  // Sauvegarde nouveau token chiffré
  await prisma.ebayAccount.update({
    where: { userId },
    data: {
      accessToken: encrypt(refreshed.access_token),
      refreshToken: refreshed.refresh_token ? encrypt(refreshed.refresh_token) : undefined,
      tokenExpiry: new Date(Date.now() + refreshed.expires_in * 1000),
    }
  });

  return refreshed.access_token;
}

async function refreshEbayToken(refreshToken: string): Promise<EbayTokens> {
  const urls = getEbayUrls();

  const res = await fetch(urls.oauth, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${Buffer.from(`${process.env.EBAY_CLIENT_ID}:${process.env.EBAY_CLIENT_SECRET}`).toString('base64')}`,
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      scope: 'https://api.ebay.com/oauth/api_scope/sell.inventory https://api.ebay.com/oauth/api_scope/sell.marketing https://api.ebay.com/oauth/api_scope/sell.account',
    }),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Refresh eBay failed: ${txt}`);
  }

  return res.json();
}

export async function fetchUserListings(userId: string) {
  const token = await getValidAccessToken(userId);
  const urls = getEbayUrls();

  const res = await fetch(`${urls.api}/sell/inventory/v1/inventory_item?limit=50`, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`eBay listings fetch failed: ${txt}`);
  }

  return res.json();
}

export async function createInventoryItem(userId: string, data: any) {
  const token = await getValidAccessToken(userId);
  const urls = getEbayUrls();

  const res = await fetch(`${urls.api}/sell/inventory/v1/inventory_item/${data.sku}`, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Language': 'fr-FR',
    },
    body: JSON.stringify(data),
  });

  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
