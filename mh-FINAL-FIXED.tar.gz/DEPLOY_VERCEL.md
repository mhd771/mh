# DÉPLOIEMENT VERCEL - MHSHOP EN LIGNE VRAI (10 min)

Tu veux ton logiciel sur internet avec un vrai lien comme https://mhshop.vercel.app où tu peux créer un compte et connecter ton vrai eBay.

Voici les étapes ultra simples, sans coder.

## ÉTAPE 1 - Mets ton code sur GitHub (2 min)

1. Va sur https://github.com -> Crée un compte si t'as pas
2. Clique "New repository" -> Nom: mhshop -> Public -> Create
3. Sur ton PC, dans VS Code terminal:
```bash
git init
git add .
git commit -m "mhshop v1"
git branch -M main
git remote add origin https://github.com/TON_PSEUDO/mhshop.git
git push -u origin main
```
Remplace TON_PSEUDO par ton pseudo GitHub.

Si tu galères, tu peux aussi glisser-déposer le dossier mhshop directement sur GitHub via le site: sur ton repo -> Add file -> Upload files.

## ÉTAPE 2 - Déploie sur Vercel (1 clic)

1. Va sur https://vercel.com -> Connecte-toi avec GitHub
2. Clique "Add New Project" -> Importe ton repo mhshop
3. Vercel détecte Next.js tout seul -> clique Deploy (ça va échouer la 1ère fois, c'est normal, il manque la base de données)

## ÉTAPE 3 - Ajoute une base de données gratuite (2 min)

Option la plus simple: Neon (gratuit)

1. Va sur https://neon.tech -> Crée compte avec GitHub
2. Create Project -> nom: mhshop -> Create
3. Copie la "Connection String" qui ressemble à:
`postgresql://user:pass@ep-xxx.neon.tech/neondb?sslmode=require`

Option 2: Vercel Postgres
- Dans ton projet Vercel -> Storage -> Create Postgres -> gratuit

## ÉTAPE 4 - Ajoute les variables d'environnement dans Vercel

Dans Vercel -> ton projet -> Settings -> Environment Variables -> ajoute:

```
DATABASE_URL = ta_connection_string_neon
AUTH_SECRET = colle le résultat de: openssl rand -base64 32
AUTH_URL = https://ton-projet.vercel.app
ENCRYPTION_KEY = colle le résultat de: openssl rand -hex 32
EBAY_CLIENT_ID = (vide pour l'instant)
EBAY_CLIENT_SECRET = (vide pour l'instant)
EBAY_RU_NAME = (vide pour l'instant)
EBAY_ENV = sandbox
OPENAI_API_KEY = (vide si t'as pas)
CRON_SECRET = un mot random long genre mon_secret_cron_12345
```

Pour générer les clés sur Windows sans openssl:
- Va sur https://generate-secret.vercel.app/32 -> copie pour AUTH_SECRET
- Va sur https://generate-random.org/hex -> 64 chars -> pour ENCRYPTION_KEY

Clique Save, puis va dans Deployments -> Redéploye (3 petits points -> Redeploy)

## ÉTAPE 5 - Lance la migration DB

Dans Vercel -> ton projet -> Settings -> General -> Build Command, vérifie que c'est:
`prisma generate && next build`

Si ça marche pas, va dans Vercel -> ton projet -> Deployments -> dernier déploiement -> View Logs, tu verras l'erreur.

Normalement après redéploiement, ton site est en ligne !

Va sur https://ton-projet.vercel.app -> /register -> crée ton compte -> /dashboard

## ÉTAPE 6 - Connecter ton vrai eBay (quand tu seras prêt)

1. Va sur https://developer.ebay.com
2. My Account -> Application Keys -> Create App -> nom mhshop
3. Onglet Auth -> ajoute Redirect URL: https://ton-projet.vercel.app/api/ebay/callback
4. eBay te donne RuName, Client ID, Client Secret
5. Retourne dans Vercel -> Settings -> Env Vars -> remplace EBAY_CLIENT_ID, EBAY_CLIENT_SECRET, EBAY_RU_NAME, passe EBAY_ENV à production quand t'es prêt
6. Redéploie
7. Va sur https://ton-projet.vercel.app/dashboard/ebay -> Connecter eBay

C'est tout ! Tu as ton SaaS en ligne.

## Besoin d'aide ?

Si tu bloques, envoie-moi:
- Capture d'écran de l'erreur Vercel
- Ton pseudo GitHub
Je te débloque.
