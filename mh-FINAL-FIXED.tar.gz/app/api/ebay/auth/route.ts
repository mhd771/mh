import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { getAuthUrl } from '@/lib/ebay-config';
import crypto from 'crypto';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  }

  // CSRF protection - state = userId + random
  const state = `${session.user.id}:${crypto.randomBytes(16).toString('hex')}`;
  
  // En prod, stocke state en DB ou cookie httpOnly pour vérif callback
  const url = getAuthUrl(state);
  
  // Option 1: redirect direct
  return NextResponse.redirect(url);
  
  // Option 2: renvoyer URL pour frontend
  // return NextResponse.json({ url });
}
