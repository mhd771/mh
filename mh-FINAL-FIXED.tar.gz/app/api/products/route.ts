import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { calculateProfit } from '@/lib/calculations';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Non auth' }, { status: 401 });
  const products = await prisma.product.findMany({ where: { userId: session.user.id }, orderBy: { createdAt: 'desc' } });
  return NextResponse.json(products);
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Non auth' }, { status: 401 });
  const body = await req.json();
  
  const result = calculateProfit({
    supplierPrice: body.supplierPrice,
    shippingCost: body.shippingCost || 0,
    platformFees: body.platformFees || 0,
    ebayFeesPercent: body.ebayFees || 12.9,
    otherFees: body.otherFees || 0,
    sellingPrice: body.sellingPrice,
  });

  const product = await prisma.product.create({
    data: {
      userId: session.user.id,
      name: body.name,
      supplierPrice: body.supplierPrice,
      shippingCost: body.shippingCost || 0,
      platformFees: body.platformFees || 0,
      ebayFees: body.ebayFees || 12.9,
      otherFees: body.otherFees || 0,
      sellingPrice: body.sellingPrice,
      quantity: body.quantity || 1,
      supplierUrl: body.supplierUrl,
      profit: result.profit,
      margin: result.margin,
      isProfitable: result.isProfitable,
    }
  });
  return NextResponse.json(product);
}
