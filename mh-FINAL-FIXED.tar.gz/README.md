# mhshop - SaaS eBay & E-commerce - VERSION COMPLÈTE

## 🚀 Démarrage ultra rapide (2 min)

```bash
# 1. Clone / dézippe
cd mhshop

# 2. Base de données - Option A: Docker (recommandé)
docker-compose up -d
# Option B: Utilise une DB Neon/Supabase et mets DATABASE_URL

# 3. Installe
npm install

# 4. Config
cp .env.example .env
# Génère ENCRYPTION_KEY:
openssl rand -hex 32
# Colle-la dans .env
# Mets DATABASE_URL="postgresql://mhshop:mhshop123@localhost:5432/mhshop"

# 5. DB
npx prisma migrate dev --name init
npx prisma generate

# 6. Lance
npm run dev
# → http://localhost:3000
# Crée compte sur /register puis /login
```

## 🔑 Connexion eBay (OAuth officiel)

Voir EBAY_SETUP.md - Tu n'as PAS besoin de donner ton mot de passe eBay.

1. developer.ebay.com → Create App
2. Récupère CLIENT_ID, CLIENT_SECRET, RuName
3. Dans .env:
EBAY_CLIENT_ID=...
EBAY_CLIENT_SECRET=...
EBAY_RU_NAME=...
EBAY_ENV=sandbox
4. Va sur /dashboard/ebay → Connecter eBay

## 📦 Fonctionnalités

- Auth sécurisée bcrypt + NextAuth v5
- Dashboard profit/marge
- CRUD Produits + calculateur: profit = vente - fournisseur - livraison - frais eBay - autres
- Générateur IA titres/descriptions (mock + prêt OpenAI)
- Surveillance prix cron toutes les heures (vercel.json)
- eBay OAuth + Inventory API officielle

## 🛡️ Sécurité

- Mots de passe hashés bcrypt
- Tokens eBay chiffrés AES-256-GCM (lib/crypto.ts)
- Aucun scraping
- CRON_SECRET protège /api/cron/price-check

## 📁 Structure

/app - Next.js 14 App Router
/app/api - Toutes les API
/lib - crypto, ebay-config, auth, db, calculations
/services/ebay - client officiel
/prisma - schema
/components - UI

Démo live du frontend: ouvre le fichier html dans /mnt/data/
