// Générateur IA - Utilise OpenAI API officielle
export async function generateProductContent(productName: string, supplierInfo?: string) {
  // En prod: appel OpenAI
  // if (!process.env.OPENAI_API_KEY) throw ...

  // MOCK conforme pour démo sans clé
  const title = `${productName} - Premium Edition | Livraison Rapide | Garantie Qualité`;
  const description = `${productName} est conçu pour offrir une expérience exceptionnelle.\n\n✅ Qualité supérieure\n✅ Livraison rapide depuis fournisseur vérifié\n✅ Support client réactif\n\nParfait pour un usage quotidien. Matériaux durables.`;

  const bullets = [
    "Qualité premium vérifiée par notre équipe",
    "Livraison rapide et suivie",
    "Garantie satisfaction 30 jours",
    "Support client 7j/7",
    "Stock disponible - Expédition sous 24h"
  ];

  const keywords = [productName.toLowerCase(), "premium", "qualité", "livraison rapide", "tendance 2024"].join(", ");

  return { title, description, bullets, keywords };
}
