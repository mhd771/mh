import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
const prisma = new PrismaClient();

async function main() {
  const hash = await bcrypt.hash('demo123', 10);
  const user = await prisma.user.upsert({
    where: { email: 'demo@mhshop.com' },
    update: {},
    create: { email: 'demo@mhshop.com', name: 'Demo', passwordHash: hash }
  });

  // Produits démo
  const products = [
    { name: 'Montre Connectée Pro', supplierPrice: 25, shippingCost: 5, platformFees: 2, ebayFees: 12.9, otherFees: 1, sellingPrice: 59.9, quantity: 20, supplierUrl: 'https://fournisseur.com/montre' },
    { name: 'Écouteurs Bluetooth', supplierPrice: 12, shippingCost: 3, platformFees: 1, ebayFees: 12.9, otherFees: 0.5, sellingPrice: 34.9, quantity: 50, supplierUrl: 'https://fournisseur.com/ecouteurs' },
    { name: 'Chargeur Rapide 65W', supplierPrice: 8, shippingCost: 2, platformFees: 1, ebayFees: 12.9, otherFees: 0.5, sellingPrice: 24.9, quantity: 100, supplierUrl: '' },
  ];

  for (const p of products) {
    const ebayFeesAmount = p.sellingPrice * p.ebayFees / 100;
    const total = p.supplierPrice + p.shippingCost + p.platformFees + ebayFeesAmount + p.otherFees;
    const profit = p.sellingPrice - total;
    const margin = (profit / p.sellingPrice) * 100;
    await prisma.product.create({ data: { userId: user.id, ...p, profit, margin, isProfitable: profit > 0 && margin >= 15 } });
  }

  console.log('Seed done: demo@mhshop.com / demo123');
}

main().then(() => process.exit(0));
