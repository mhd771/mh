import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { calculateProfit } from '@/lib/calculations';

const prisma = new PrismaClient();

// Vercel Cron: GET /api/cron/price-check - Header: Authorization: Bearer CRON_SECRET
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const products = await prisma.product.findMany();
  let alertsCreated = 0;

  for (const p of products) {
    // ICI: Appel API fournisseur AUTORISÉE uniquement
    // Exemple: const newSupplierPrice = await fetchSupplierPrice(p.supplierUrl)
    // Pour démo, on simule pas de changement sans clé
    
    // Recalcul profit
    const result = calculateProfit({
      supplierPrice: p.supplierPrice,
      shippingCost: p.shippingCost,
      platformFees: p.platformFees,
      ebayFeesPercent: p.ebayFees,
      otherFees: p.otherFees,
      sellingPrice: p.sellingPrice,
    });

    await prisma.product.update({
      where: { id: p.id },
      data: {
        profit: result.profit,
        margin: result.margin,
        isProfitable: result.isProfitable,
        lastPriceCheck: new Date(),
      }
    });

    if (result.alert && result.profit < 0) {
      await prisma.priceAlert.create({
        data: {
          productId: p.id,
          oldPrice: p.supplierPrice,
          newPrice: p.supplierPrice, // en vrai: nouveau prix détecté
          message: result.alert,
        }
      });
      alertsCreated++;
    }
  }

  return NextResponse.json({ checked: products.length, alerts: alertsCreated });
}
