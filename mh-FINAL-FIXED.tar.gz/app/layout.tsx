import './globals.css';
import { Inter } from 'next/font/google';
const inter = Inter({ subsets: ['latin'] });
export const metadata = { title: 'mhshop - SaaS eBay & E-commerce', description: 'Gère tes ventes eBay et e-commerce' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="fr" className="dark"><body className={inter.className + ' bg-[#0a0a0f] text-white min-h-screen'}>{children}</body></html>;
}
