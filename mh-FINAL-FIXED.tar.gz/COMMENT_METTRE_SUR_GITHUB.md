# COMMENT METTRE MHSHOP SUR GITHUB SANS CODER (2 min)

Tu as eu 404 parce que ton GitHub est vide. Vercel a déployé du vide.

## METHODE LA PLUS SIMPLE - Glisser-déposer sur GitHub

### 1. Télécharge et décompresse

Télécharge: mhshop-vercel-ready.tar.gz
- Sur Windows: installe 7-Zip (7-zip.org)
- Clic droit -> Extraire ici -> tu auras un dossier "mhshop" avec plein de fichiers dedans (app, lib, prisma, package.json...)

### 2. Crée ton compte GitHub

Va sur https://github.com
- Sign up si t'as pas de compte

### 3. Crée un repo vide

- Clique en haut à droite sur "+" -> New repository
- Repository name: mhshop
- Coche Public
- NE coche PAS "Add a README"
- Clique Create repository

### 4. Upload les fichiers (sans ligne de commande)

Tu arrives sur une page qui dit "Quick setup"

Clique sur le lien bleu: "uploading an existing file"

- Ouvre ton dossier mhshop sur ton PC
- Sélectionne TOUS les fichiers dedans (Ctrl+A)
- Glisse-les dans la zone de GitHub qui dit "Drag files here"

Attends que tout upload (30 sec)

- En bas, clique sur le bouton vert "Commit changes"

C'EST TOUT ! Ton GitHub a maintenant tous les fichiers.

### 5. Déploie sur Vercel

- Va sur https://vercel.com -> Login avec GitHub
- Add New Project -> tu vois ton repo mhshop -> Import
- Framework: Next.js (détecté auto)
- Root Directory: laisse vide si tu as uploadé les fichiers directement, ou mets "mhshop" si tu as uploadé le dossier entier
- Clique Deploy -> ça va échouer la 1ère fois (normal)

### 6. Ajoute les 3 clés

Va dans Vercel -> ton projet -> Settings -> Environment Variables

Ajoute:
DATABASE_URL = ta clé Neon (va sur neon.tech -> Create Project -> copie la connection string)
AUTH_SECRET = https://generate-secret.vercel.app/32 -> copie
ENCRYPTION_KEY = https://generate-random.org/hex -> mets 64 -> copie

Save

### 7. Redéploie

Deployments -> ... -> Redeploy (sans cache)

Attends Ready -> Visit -> va sur /register

---

## METHODE ENCORE PLUS SIMPLE - Sans GitHub du tout

Si GitHub te saoule, tu peux déployer direct sans GitHub:

1. Va sur https://vercel.com/new
2. Au lieu de importer GitHub, clique en bas sur "Browse" ou installe Vercel CLI
3. Mais le plus simple reste GitHub glisser-déposer.

Si tu bloques, envoie-moi une capture de ton GitHub, je te dis si les fichiers sont bien là.
