export interface ProfitInput {
  supplierPrice: number;
  shippingCost: number;
  platformFees: number;
  ebayFeesPercent: number; // ex: 12.9%
  otherFees: number;
  sellingPrice: number;
}

export interface ProfitResult {
  profit: number;
  margin: number;
  ebayFeesAmount: number;
  totalCosts: number;
  isProfitable: boolean;
  alert: string | null;
}

export function calculateProfit(input: ProfitInput): ProfitResult {
  const ebayFeesAmount = (input.sellingPrice * input.ebayFeesPercent) / 100;
  const totalCosts = input.supplierPrice + input.shippingCost + input.platformFees + ebayFeesAmount + input.otherFees;
  const profit = input.sellingPrice - totalCosts;
  const margin = input.sellingPrice > 0 ? (profit / input.sellingPrice) * 100 : 0;

  let alert: string | null = null;
  if (profit < 0) alert = "Marge négative ! Prix de vente trop bas.";
  else if (profit < 5) alert = "Bénéfice faible (< 5€)";
  else if (margin < 15) alert = "Marge faible (< 15%)";

  return {
    profit: parseFloat(profit.toFixed(2)),
    margin: parseFloat(margin.toFixed(2)),
    ebayFeesAmount: parseFloat(ebayFeesAmount.toFixed(2)),
    totalCosts: parseFloat(totalCosts.toFixed(2)),
    isProfitable: profit > 0 && margin >= 15,
    alert,
  };
}
