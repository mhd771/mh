// Config centrale eBay - Sandbox vs Production

export const EBAY_CONFIG = {
  sandbox: {
    oauth: 'https://api.sandbox.ebay.com/identity/v1/oauth2/token',
    authorize: 'https://auth.sandbox.ebay.com/oauth2/authorize',
    api: 'https://api.sandbox.ebay.com',
  },
  production: {
    oauth: 'https://api.ebay.com/identity/v1/oauth2/token',
    authorize: 'https://auth.ebay.com/oauth2/authorize',
    api: 'https://api.ebay.com',
  }
};

export function getEbayEnv() {
  return (process.env.EBAY_ENV as 'sandbox' | 'production') || 'sandbox';
}

export function getEbayUrls() {
  return EBAY_CONFIG[getEbayEnv()];
}

export const EBAY_SCOPES = [
  'https://api.ebay.com/oauth/api_scope/sell.inventory',
  'https://api.ebay.com/oauth/api_scope/sell.marketing',
  'https://api.ebay.com/oauth/api_scope/sell.account',
].join(' ');

export function getAuthUrl(state: string): string {
  const urls = getEbayUrls();
  const params = new URLSearchParams({
    client_id: process.env.EBAY_CLIENT_ID!,
    response_type: 'code',
    redirect_uri: process.env.EBAY_RU_NAME!,
    scope: EBAY_SCOPES,
    state, // CSRF protection
    prompt: 'login',
  });
  return `${urls.authorize}?${params.toString()}`;
}
