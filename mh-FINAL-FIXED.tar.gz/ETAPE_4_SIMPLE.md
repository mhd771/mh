# ETAPE 4 - ULTRA SIMPLE - Où coller les clés dans Vercel

Tu es bloqué à l'étape 4, c'est normal, c'est l'étape la plus technique. Je te l'explique comme si t'avais jamais fait.

## C'EST QUOI CES CLES ?

C'est comme des mots de passe que Vercel a besoin pour faire tourner ton site.
Sans elles, il affiche 404.

Tu en as besoin de 3 seulement pour commencer.

## TES 2 CLES DEJA PRETES (je te les ai générées)

Tu as juste à copier-coller, pas besoin d'aller sur d'autres sites:

### Clé 1 - AUTH_SECRET:
```
ZbG0P4eqrzlTgtykgMkeEohClMx4lXIxht1znDnAcyw=
```

### Clé 2 - ENCRYPTION_KEY:
```
4f4d5a7de26d46450ae6bc3e73253386407f6e367d46ae3903a24ceb7d14391a
```

### Clé 3 - DATABASE_URL:
Celle-là tu dois la créer toi-même sur neon.tech (2 min):

1. Va sur https://neon.tech
2. Clique "Sign up" -> connecte avec GitHub
3. Clique "Create Project"
   - Name: mhshop
   - Region: Europe
   - Clique Create
4. Tu arrives sur un écran avec une ligne qui commence par "postgresql://..."
   - Clique sur le bouton "Copy" à côté
   - C'est ta DATABASE_URL, elle ressemble à:
   postgresql://neondb_owner:xxxxx@ep-xxxx.eu-central-1.aws.neon.tech/neondb?sslmode=require

Garde cette ligne, c'est ta 3ème clé.

## OU COLLER CES 3 CLES DANS VERCEL ?

1. Va sur https://vercel.com
2. Clique sur ton projet "mh" (ou "mhshop")
3. En haut, clique sur "Settings" (icône engrenage)
4. Dans le menu de gauche, clique sur "Environment Variables"
5. Tu vois un formulaire avec "Key" et "Value"

Ajoute la 1ère clé:
- Dans "Key": écris DATABASE_URL
- Dans "Value": colle ta ligne postgresql://... de Neon
- Clique "Add"

Ajoute la 2ème clé:
- Key: AUTH_SECRET
- Value: colle ZbG0P4eqrzlTgtykgMkeEohClMx4lXIxht1znDnAcyw=
- Add

Ajoute la 3ème clé:
- Key: ENCRYPTION_KEY
- Value: colle 4f4d5a7de26d46450ae6bc3e73253386407f6e367d46ae3903a24ceb7d14391a
- Add

Tu dois voir 3 lignes dans la liste.

6. Clique sur le bouton "Save" en bas

7. Maintenant il faut redéployer:
- En haut, clique sur "Deployments"
- Sur la première ligne (ton dernier déploiement), clique sur les 3 petits points "..." à droite
- Clique "Redeploy"
- Une fenêtre s'ouvre, DECOCHE la case "Use existing Build Cache"
- Clique "Redeploy" en rouge

Attends 2 minutes. Tu vas voir "Building" puis "Ready" avec des confettis.

8. Clique sur "Visit" ou sur le lien en haut (https://mh-xxxx.vercel.app)

9. Ajoute /register à la fin: https://mh-xxxx.vercel.app/register

Crée ton compte et c'est bon !

---

Si tu vois encore 404 ou Failed, clique sur le déploiement -> "View Logs" -> fais une capture d'écran et envoie-la moi.

Tes clés sont aussi dans le fichier MES_CLES_VERSEL.txt
