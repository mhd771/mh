import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Non auth' }, { status: 401 });

  await prisma.ebayAccount.delete({ where: { userId: session.user.id } }).catch(() => {});
  
  return NextResponse.json({ success: true });
}
