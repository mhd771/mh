# GUIDE ULTRA SIMPLE - OUVRIR MHSHOP SUR TON PC (5 min)

Tu as dit "ya rien sur mon pc pour l'ouvrir" -> Normal, c'est un logiciel de dev, pas un .exe. Voici comment faire, étape par étape, même si tu n'as jamais codé.

## TU N'AS RIEN À ME DONNER

Surtout pas ton mot de passe eBay. Jamais. Le logiciel tourne chez toi.

## ETAPE 1 - INSTALLE 2 TRUCS (une fois)

1. **Node.js** (fait tourner le logiciel):
   - Va sur https://nodejs.org
   - Clique sur le gros bouton vert "LTS" -> Installe tout par défaut

2. **VS Code** (pour ouvrir le code):
   - Va sur https://code.visualstudio.com
   - Installe

C'est tout. Pas besoin de Docker si tu prends la version simple.

## ETAPE 2 - TÉLÉCHARGE LE LOGICIEL

- Télécharge ce fichier: mhshop-complet.tar.gz (je te l'ai mis en lien)
- Si tu es sur Windows, installe 7-Zip (https://www.7-zip.org) pour l'ouvrir
- Clic droit -> Extraire ici -> tu obtiens un dossier "mhshop"

## ETAPE 3 - OUVRE-LE

1. Ouvre VS Code
2. Fichier -> Ouvrir Dossier -> choisis le dossier "mhshop"
3. Dans VS Code, en haut: Terminal -> Nouveau Terminal
4. Dans le terminal noir qui s'ouvre en bas, colle ces commandes une par une (Entrée après chaque):

```bash
npm install
```
(Attends 2 min, ça installe tout)

```bash
cp .env.example .env
```
Sur Windows si ça marche pas:
```bash
copy .env.example .env
```

```bash
npx prisma migrate dev --name init
npx prisma db seed
```

```bash
npm run dev
```

Si tu vois "Ready on http://localhost:3000" c'est bon !

## ETAPE 4 - OUVRE DANS TON NAVIGATEUR

Va sur: http://localhost:3000

- Clique "Créer mon compte"
- Mets ton email / mot de passe (c'est local, chez toi)
- Ensuite "Connexion" avec demo@mhshop.com / demo123 si tu veux tester direct

Tu es dans le dashboard !

## ETAPE 5 - CONNECTER EBAY (quand tu seras prêt)

Tu n'as pas besoin de le faire maintenant.

Quand tu voudras:
1. Va sur developer.ebay.com (crée un compte dev avec ton compte eBay vendeur)
2. Crée une app -> tu récupères 3 codes
3. Tu les colles dans le fichier .env (ouvre-le dans VS Code)
4. Redémarre npm run dev
5. Dans mhshop: Dashboard -> eBay -> Connecter eBay

Tu seras redirigé sur eBay.com officiel pour te connecter. Ton mot de passe reste sur eBay.

## VERSION SANS DOCKER - SQLITE

J'ai mis une version simple qui utilise un fichier dev.db au lieu de PostgreSQL. Pour l'utiliser:

Dans prisma/schema.prisma, remplace tout par le contenu de prisma/schema.sqlite.prisma (je l'ai ajouté)

Et dans .env, mets:
DATABASE_URL="file:./dev.db"

Puis refais:
npx prisma migrate dev --name init

## SI TU GALÈRES

Dis-moi:
- Tu es sur Windows ou Mac ?
- Tu as réussi à installer Node.js ?
Je te fais une vidéo étape par étape ou je te déploie une version en ligne sur Vercel que tu ouvres juste avec un lien, sans rien installer.
